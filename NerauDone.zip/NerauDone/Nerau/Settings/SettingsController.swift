import UIKit


final class SettingsController: UITableViewController {
    @IBAction func closeSettings(sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
