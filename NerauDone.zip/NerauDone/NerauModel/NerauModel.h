//
//  NerauModel.h
//  NerauModel
//
//  Created by Benedikt Terhechte on 18.06.19.
//  Copyright © 2019 Benedikt Terhechte. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NerauModel.
FOUNDATION_EXPORT double NerauModelVersionNumber;

//! Project version string for NerauModel.
FOUNDATION_EXPORT const unsigned char NerauModelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NerauModel/PublicHeader.h>


